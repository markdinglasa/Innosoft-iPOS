# CHANGES

- functions
- [x] Filter the sales summary of GCash sales where it only show the collection
- [x] Change the Delivery Report to Warranty
- 2024-06-03
